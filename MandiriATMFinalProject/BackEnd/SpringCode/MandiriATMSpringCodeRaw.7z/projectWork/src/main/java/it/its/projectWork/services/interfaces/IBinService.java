package it.its.projectWork.services.interfaces;

import java.util.List;

public interface IBinService {
	
	public List<String> findAllBinValues();
}
