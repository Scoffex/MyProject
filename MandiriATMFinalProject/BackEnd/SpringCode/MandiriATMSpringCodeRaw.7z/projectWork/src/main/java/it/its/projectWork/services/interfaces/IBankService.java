package it.its.projectWork.services.interfaces;

import java.util.List;

public interface IBankService {
	public List<String> findAllCodes();
}
