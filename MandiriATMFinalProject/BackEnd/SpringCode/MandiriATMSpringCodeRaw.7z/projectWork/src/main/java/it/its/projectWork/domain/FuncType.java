package it.its.projectWork.domain;

public enum FuncType {
	WITHDRAWAL, DEPOSIT, BALANCE_INQUIRY, PAYMENT
}
